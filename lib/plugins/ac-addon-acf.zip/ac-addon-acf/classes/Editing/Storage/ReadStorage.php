<?php

namespace ACA\ACF\Editing\Storage;

interface ReadStorage {

	public function get( $id );

}