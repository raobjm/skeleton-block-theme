<?php

namespace ACA\ACF\Field\Type;

use ACA\ACF\Field;

class Image extends Field {

}