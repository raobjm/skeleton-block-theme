<?php

namespace ACA\ACF\Field;

interface SaveFormat {

	/**
	 * @return string
	 */
	public function get_save_format();

}