<?php

namespace ACA\ACF\Field;

interface DefaultValue {

	/**
	 * @return string
	 */
	public function get_default_value();

}