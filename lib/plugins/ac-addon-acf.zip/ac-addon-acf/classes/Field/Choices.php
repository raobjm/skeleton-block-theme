<?php

namespace ACA\ACF\Field;

interface Choices {

	/**
	 * @return array
	 */
	public function get_choices();

}